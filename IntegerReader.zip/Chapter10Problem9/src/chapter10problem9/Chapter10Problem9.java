/*
* IT-265 Java Programming, Summer 2017
* Instructor: Martin P. Walsh
* Student Name: Natasha Ostrander
* Homework Assignment: Chap 10, Problem 9
* Purpose of Assignment: To read a file of integers and write them in largest 
* to smallest.
*
 */
package chapter10problem9;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

public class Chapter10Problem9 
{

    public static void main(String[] args) 
    {
        // Course Information
        System.out.println("IT-2650 Java Programming");
        System.out.println("Student Name: Natasha Ostrander");
        System.out.println("Homework Assignment: Chapter 10, Problem 9");
        System.out.println("________________________________");
        System.out.println("");

        try {
            ObjectOutputStream os = new ObjectOutputStream(new FileOutputStream("writeIntFile.dat"));
            System.out.println("Ten Random integer numbers are: ");
            for (int i = 0; i < 10; i++) {
                int number = (int) (Math.random() * 20) + 1;
                System.out.println(" " + number);
                os.writeInt(number);
            }
            os.close();
//            ObjectInputStream is = new ObjectInputStream(new FileInputStream("writeIntFile.dat"));

            ObjectInputStream is = new ObjectInputStream(new FileInputStream("Chapter10numbers.dat"));            
            
            int small = 20, large = 0;
            try {
                while (true) {
                    int nextInt = is.readInt();
                    if (nextInt < small) {
                        small = nextInt;
                    }
                    if (nextInt > large) {
                        large = nextInt;
                    }
                }
            } catch (IOException e) {
                System.out.println("\nLargest number: " + large);
                System.out.println("Smallest number: " + small);
            }
        } catch (IOException e) {
            System.out.println("Error with file output.");
        }
    }

}
